import csv
import openai

openai.api_key = "YOUR_OPENAI_API_KEY"  # replace with your actual key

# ✅ Correct path to your CSV file
csv_file_path = "/Users/vishvakbhatt/Downloads/hackathon_datasets_bundle/participants.csv"

def load_attendees(csv_path):
    attendees = []
    with open(csv_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            attendees.append(row)
    return attendees

def format_attendee_list(attendees):
    return "\n".join([f"- {a['Name']} ({a.get('Organization', 'Unknown')})" for a in attendees])

def ask_agent(question, attendees):
    if "attendee" in question.lower() or "registered" in question.lower():
        attendee_text = format_attendee_list(attendees)
        return f"Here is the list of registered attendees:\n{attendee_text}"
    else:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an event assistant that shows attendee information when asked."},
                {"role": "user", "content": question}
            ]
        )
        return response.choices[0].message.content.strip()

if __name__ == "__main__":
    attendees = load_attendees(csv_file_path)
    print("🤖 Ask a question about attendees (or type 'exit' to quit):")
    
    while True:
        user_input = input("🧑 You: ")
        if user_input.lower() in ['exit', 'quit']:
            print("👋 Goodbye!")
            break
        reply = ask_agent(user_input, attendees)
        print(f"🤖 {reply}\n")
