import json
from datetime import datetime
import openai

# ✅ Azure OpenAI Configuration
openai.api_type = "azure"
openai.api_key = "8QRutvmpeSE3H2eQRt6DpvymhfzLVPX2VqDZuVMIOWe1fNQS52bIJQQJ99BDACYeBjFXJ3w3AAAAACOGjWih"  # Replace with your key
openai.api_base = "https://unocode4377087879.openai.azure.com/"  # Replace with your Azure endpoint
openai.api_version = "2024-03-01-preview"
DEPLOYMENT_NAME = "gpt-4"  # or your deployment name

# ✅ Load local data files
def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

participants = load_json("/Users/vishvakbhatt/Downloads/hackathon_datasets_bundle/participants.json")
tasks = load_json("/Users/vishvakbhatt/Downloads/hackathon_datasets_bundle/task_tracker.json")
alerts = load_json("/Users/vishvakbhatt/Downloads/hackathon_datasets_bundle/incident_alerts.json")
schedule = load_json("/Users/vishvakbhatt/Downloads/hackathon_datasets_bundle/event_schedule.json")

# ✅ Helpdesk logic
def handle_helpdesk(question):
    q = question.lower()
    if "room" in q:
        return "📍 Room inquiry noted. We'll check availability."
    elif "mentor" in q:
        return "🧑‍🏫 Mentor scheduling conflict logged. A backup will be assigned."
    elif "team" in q:
        return "👥 Team changes are allowed if above minimum size. Proceed."
    else:
        return None  # fallback to AI

# ✅ Deadline Reminder
def send_deadline_reminders():
    today = datetime.today().date()
    print("🔔 Checking for task deadlines...")
    for task in tasks:
        due = datetime.strptime(task["Due"], "%Y-%m-%d").date()
        if (due - today).days <= 1 and task["Status"].lower() != "completed":
            print(f"[Reminder Email Sent] Task: {task['Task']} — Owner: {task['Owner']} — Due: {task['Due']}")

# ✅ Last-Minute Update Notification
def notify_teams():
    print("📢 Notifying teams of last-minute updates...")
    for alert in alerts:
        print(f"[Notification Sent] {alert['Type']} - {alert['Message']} at {alert['Time']}")

# ✅ Mentor Check-in Log
def log_mentor_checkins():
    print("📋 Mentor Check-In Summary:")
    mentor_session = next((s for s in schedule if "mentor" in s["Event"].lower()), None)
    if mentor_session:
        print(f"Session: {mentor_session['Event']} at {mentor_session['Time']} in {mentor_session['Location']}")
        for p in participants:
            if "sat" in p["Availability"].lower():
                print(f"👤 {p['Name']} ({p['Skills']}) — Available: {p['Availability']}")
    else:
        print("❌ No mentor session scheduled.")

# ✅ Ask Azure OpenAI Agent if fallback is needed
def ask_ai_agent(question):
    response = openai.ChatCompletion.create(
        engine=DEPLOYMENT_NAME,
        messages=[
            {"role": "system", "content": "You are a smart assistant for managing a hackathon event. Help answer questions about schedules, tasks, teams, mentors, or alerts."},
            {"role": "user", "content": question}
        ]
    )
    return response["choices"][0]["message"]["content"].strip()

# ✅ Main Interaction Loop
if __name__ == "__main__":
    print("🤖 Ask a question or type:")
    print("   - 'remind' for deadlines")
    print("   - 'notify' for alerts")
    print("   - 'mentor' for check-ins")
    print("   - or ask anything helpdesk-related!\n")

    while True:
        user_input = input("🧑 You: ").strip()
        if user_input.lower() in ['exit', 'quit']:
            print("👋 Exiting.")
            break
        elif user_input.lower() == "remind":
            send_deadline_reminders()
        elif user_input.lower() == "notify":
            notify_teams()
        elif user_input.lower() == "mentor":
            log_mentor_checkins()
        else:
            local_response = handle_helpdesk(user_input)
            if local_response:
                print(f"🤖 {local_response}")
            else:
                ai_reply = ask_ai_agent(user_input)
                print(f"🤖 {ai_reply}")
